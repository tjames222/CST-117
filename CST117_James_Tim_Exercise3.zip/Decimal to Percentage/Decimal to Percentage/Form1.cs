﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decimal_to_Percentage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Declare variables for holding input
        double decimalIn;
        double decimalConverted;
        string percentOperator = "%";

        private void conversionButton_Click(object sender, EventArgs e)
        {
            // Get the decimal and assign it to appropriate variable
            decimalIn = double.Parse(decimalInput.Text);

            // Calculate the decimal to percentage conversion
            decimalConverted = decimalIn * 100;

            // Display the decimal converted to a percentage
            solution.Text = decimalConverted.ToString() + percentOperator;
        }
    }
}
