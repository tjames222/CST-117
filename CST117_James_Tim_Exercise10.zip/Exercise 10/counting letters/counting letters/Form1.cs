﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace counting_letters
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Declaring global variables
        string[] str;
        int count;
        StreamReader inputFile;

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void openFileButton_Click(object sender, EventArgs e)
        {

            // Start Directory
            openFiles.InitialDirectory = "C:/Documents";

            // Operations for open and cancel button
            if (openFiles.ShowDialog() == DialogResult.OK)
            {
                // Continue operations
            }
            else
            {
                // Close 
            }

            // Pass file name to label
            fileName.Text = openFiles.FileName;
            inputFile = File.OpenText(openFiles.FileName);
        }

        private void checkFileButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Read txt file, split each word and save to array
                while (!inputFile.EndOfStream)
                {
                    str = inputFile.ReadToEnd().Split('.', ' ');
                }
                inputFile.Close();
            }
            catch (Exception ex)
            {
                // Error Message
                MessageBox.Show(ex.Message);
            }

            // Test each word for end char e or t
            foreach (string s in str)
            {
                if (s.EndsWith("e") || (s.EndsWith("t")))
                {
                    count++;    
                }
            }

            // Display count of words ending with e or t
            MessageBox.Show("There are " + count + " occurences of the" +
                    " letters t or e at the end of a word.");

        }
    }
}
