﻿namespace Decimal_to_Percentage
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;


        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }



        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.conversionButton = new System.Windows.Forms.Button();
            this.decimalInput = new System.Windows.Forms.TextBox();
            this.decimalLabel = new System.Windows.Forms.Label();
            this.percentageLabel = new System.Windows.Forms.Label();
            this.solution = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // conversionButton
            // 
            this.conversionButton.Location = new System.Drawing.Point(244, 105);
            this.conversionButton.Name = "conversionButton";
            this.conversionButton.Size = new System.Drawing.Size(134, 41);
            this.conversionButton.TabIndex = 0;
            this.conversionButton.Text = "CONVERT";
            this.conversionButton.UseVisualStyleBackColor = true;
            this.conversionButton.Click += new System.EventHandler(this.conversionButton_Click);
            // 
            // decimalInput
            // 
            this.decimalInput.Location = new System.Drawing.Point(199, 54);
            this.decimalInput.Name = "decimalInput";
            this.decimalInput.Size = new System.Drawing.Size(179, 20);
            this.decimalInput.TabIndex = 1;
            // 
            // decimalLabel
            // 
            this.decimalLabel.AutoSize = true;
            this.decimalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decimalLabel.Location = new System.Drawing.Point(12, 52);
            this.decimalLabel.Name = "decimalLabel";
            this.decimalLabel.Size = new System.Drawing.Size(181, 20);
            this.decimalLabel.TabIndex = 2;
            this.decimalLabel.Text = "Enter a decimal number:";
            // 
            // percentageLabel
            // 
            this.percentageLabel.AutoSize = true;
            this.percentageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.percentageLabel.Location = new System.Drawing.Point(22, 177);
            this.percentageLabel.Name = "percentageLabel";
            this.percentageLabel.Size = new System.Drawing.Size(171, 20);
            this.percentageLabel.TabIndex = 4;
            this.percentageLabel.Text = "Percentage equivalent:";
            // 
            // solution
            // 
            this.solution.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.solution.Location = new System.Drawing.Point(199, 177);
            this.solution.Name = "solution";
            this.solution.Size = new System.Drawing.Size(179, 23);
            this.solution.TabIndex = 5;
            this.solution.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(436, 249);
            this.Controls.Add(this.solution);
            this.Controls.Add(this.percentageLabel);
            this.Controls.Add(this.decimalLabel);
            this.Controls.Add(this.decimalInput);
            this.Controls.Add(this.conversionButton);
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Name = "Form1";
            this.Text = "Decimal to Percent Conversion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion



        // Accept user input decimal number and converts it to a percentage
        private System.Windows.Forms.Button conversionButton;
        private System.Windows.Forms.TextBox decimalInput; 
        private System.Windows.Forms.Label decimalLabel;
        private System.Windows.Forms.Label percentageLabel;
        private System.Windows.Forms.Label solution;
    }
}

